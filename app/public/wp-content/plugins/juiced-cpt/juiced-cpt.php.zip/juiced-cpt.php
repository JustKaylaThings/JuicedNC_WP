<?php
/**
 * Plugin Name: Juiced CPT
 * Description: Registers the Herb and Menu Item custom post types, their taxonomies, and ACF field groups for the Juiced NC storefront.
 * Version: 1.0.0
 * Author: Juiced NC
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// -------------------------------------------------------------------------
// 1. Custom Post Type: Herb
// -------------------------------------------------------------------------
function juiced_register_herb_cpt() {
    $labels = [
        'name'               => 'Herbs',
        'singular_name'      => 'Herb',
        'add_new'            => 'Add New',
        'add_new_item'       => 'Add New Herb',
        'edit_item'          => 'Edit Herb',
        'new_item'           => 'New Herb',
        'view_item'          => 'View Herb',
        'search_items'       => 'Search Herbs',
        'not_found'          => 'No herbs found',
        'not_found_in_trash' => 'No herbs found in Trash',
    ];

    register_post_type( 'herb', [
        'labels'              => $labels,
        'public'              => true,
        'has_archive'         => true,
        'supports'            => [ 'title', 'editor', 'excerpt', 'thumbnail' ],
        'rewrite'             => [ 'slug' => 'herbs' ],
        'menu_icon'           => 'dashicons-palmtree',
        // WPGraphQL settings
        'show_in_graphql'     => true,
        'graphql_single_name' => 'herb',
        'graphql_plural_name' => 'herbs',
    ] );
}
add_action( 'init', 'juiced_register_herb_cpt' );

// -------------------------------------------------------------------------
// 2. Taxonomy: Herb Category
// -------------------------------------------------------------------------
function juiced_register_herb_category_taxonomy() {
    $labels = [
        'name'          => 'Herb Categories',
        'singular_name' => 'Herb Category',
        'search_items'  => 'Search Herb Categories',
        'all_items'     => 'All Herb Categories',
        'edit_item'     => 'Edit Herb Category',
        'update_item'   => 'Update Herb Category',
        'add_new_item'  => 'Add New Herb Category',
        'new_item_name' => 'New Herb Category Name',
        'menu_name'     => 'Herb Categories',
    ];

    register_taxonomy( 'herb_category', [ 'herb' ], [
        'labels'            => $labels,
        'hierarchical'      => true,
        'public'            => true,
        'rewrite'           => [ 'slug' => 'herb-category' ],
        // WPGraphQL settings
        'show_in_graphql'     => true,
        'graphql_single_name' => 'herbCategory',
        'graphql_plural_name' => 'herbCategories',
    ] );
}
add_action( 'init', 'juiced_register_herb_category_taxonomy' );

// -------------------------------------------------------------------------
// 3. ACF Field Group: Herb Fields
// -------------------------------------------------------------------------
function juiced_register_herb_acf_fields() {
    if ( ! function_exists( 'acf_add_local_field_group' ) ) {
        return;
    }

    acf_add_local_field_group( [
        'key'    => 'group_herb_fields',
        'title'  => 'Herb Fields',
        'fields' => [
            [
                'key'               => 'field_herb_latin_name',
                'label'             => 'Latin Name',
                'name'              => 'latin_name',
                'type'              => 'text',
                'show_in_graphql'   => 1,
                'graphql_field_name'=> 'latinName',
            ],
            [
                'key'               => 'field_herb_benefits',
                'label'             => 'Benefits',
                'name'              => 'benefits',
                'type'              => 'textarea',
                'show_in_graphql'   => 1,
                'graphql_field_name'=> 'benefits',
            ],
            [
                'key'               => 'field_herb_usage_notes',
                'label'             => 'Usage Notes',
                'name'              => 'usage_notes',
                'type'              => 'textarea',
                'show_in_graphql'   => 1,
                'graphql_field_name'=> 'usageNotes',
            ],
            [
                'key'               => 'field_herb_cautions',
                'label'             => 'Cautions',
                'name'              => 'cautions',
                'type'              => 'textarea',
                'show_in_graphql'   => 1,
                'graphql_field_name'=> 'cautions',
            ],
            [
                'key'               => 'field_herb_preparation_methods',
                'label'             => 'Preparation Methods',
                'name'              => 'preparation_methods',
                'type'              => 'checkbox',
                'choices'           => [
                    'tea'       => 'Tea / Infusion',
                    'tincture'  => 'Tincture',
                    'capsule'   => 'Capsule',
                    'topical'   => 'Topical',
                    'raw'       => 'Raw / Fresh',
                    'decoction' => 'Decoction',
                    'syrup'     => 'Syrup',
                    'powder'    => 'Powder',
                ],
                'show_in_graphql'   => 1,
                'graphql_field_name'=> 'preparationMethods',
            ],
            [
                'key'               => 'field_herb_origin',
                'label'             => 'Origin',
                'name'              => 'origin',
                'type'              => 'text',
                'show_in_graphql'   => 1,
                'graphql_field_name'=> 'origin',
            ],
            [
                'key'               => 'field_herb_related_products',
                'label'             => 'Related Products',
                'name'              => 'related_products',
                'type'              => 'relationship',
                'post_type'         => [ 'product' ],
                'filters'           => [ 'search' ],
                'return_format'     => 'object',
                'show_in_graphql'   => 1,
                'graphql_field_name'=> 'relatedProducts',
            ],
        ],
        'location' => [
            [
                [
                    'param'    => 'post_type',
                    'operator' => '==',
                    'value'    => 'herb',
                ],
            ],
        ],
        'show_in_graphql' => 1,
        'graphql_field_name' => 'herbFields',
    ] );
}
add_action( 'acf/init', 'juiced_register_herb_acf_fields' );

// -------------------------------------------------------------------------
// 4. Custom Post Type: Menu Item
// -------------------------------------------------------------------------
function juiced_register_menu_item_cpt() {
    $labels = [
        'name'               => 'Menu Items',
        'singular_name'      => 'Menu Item',
        'add_new'            => 'Add New',
        'add_new_item'       => 'Add New Menu Item',
        'edit_item'          => 'Edit Menu Item',
        'new_item'           => 'New Menu Item',
        'view_item'          => 'View Menu Item',
        'search_items'       => 'Search Menu Items',
        'not_found'          => 'No menu items found',
        'not_found_in_trash' => 'No menu items found in Trash',
    ];

    register_post_type( 'menu_item', [
        'labels'              => $labels,
        'public'              => true,
        'has_archive'         => false,
        'supports'            => [ 'title', 'editor', 'thumbnail', 'page-attributes' ],
        'rewrite'             => [ 'slug' => 'menu-items' ],
        'menu_icon'           => 'dashicons-food',
        'show_in_graphql'     => true,
        'graphql_single_name' => 'foodItem',
        'graphql_plural_name' => 'foodItems',
    ] );
}
add_action( 'init', 'juiced_register_menu_item_cpt' );

// -------------------------------------------------------------------------
// 5. Taxonomy: Menu Section
// -------------------------------------------------------------------------
function juiced_register_menu_section_taxonomy() {
    $labels = [
        'name'          => 'Menu Sections',
        'singular_name' => 'Menu Section',
        'search_items'  => 'Search Menu Sections',
        'all_items'     => 'All Menu Sections',
        'edit_item'     => 'Edit Menu Section',
        'update_item'   => 'Update Menu Section',
        'add_new_item'  => 'Add New Menu Section',
        'new_item_name' => 'New Menu Section Name',
        'menu_name'     => 'Menu Sections',
    ];

    register_taxonomy( 'menu_section', [ 'menu_item' ], [
        'labels'              => $labels,
        'hierarchical'        => true,
        'public'              => true,
        'rewrite'             => [ 'slug' => 'menu-section' ],
        'show_in_graphql'     => true,
        'graphql_single_name' => 'menuSection',
        'graphql_plural_name' => 'menuSections',
    ] );
}
add_action( 'init', 'juiced_register_menu_section_taxonomy' );

// -------------------------------------------------------------------------
// 6. ACF Field Group: Menu Item Details
// -------------------------------------------------------------------------
function juiced_register_menu_item_acf_fields() {
    if ( ! function_exists( 'acf_add_local_field_group' ) ) {
        return;
    }

    acf_add_local_field_group( [
        'key'    => 'group_menu_item_details',
        'title'  => 'Menu Item Details',
        'fields' => [
            [
                'key'                => 'field_menu_item_ingredients',
                'label'              => 'Ingredients',
                'name'               => 'ingredients',
                'type'               => 'textarea',
                'show_in_graphql'    => 1,
                'graphql_field_name' => 'ingredients',
            ],
            [
                'key'                => 'field_menu_item_featured',
                'label'              => 'Featured',
                'name'               => 'featured',
                'type'               => 'true_false',
                'ui'                 => 1,
                'show_in_graphql'    => 1,
                'graphql_field_name' => 'featured',
            ],
        ],
        'location' => [
            [
                [
                    'param'    => 'post_type',
                    'operator' => '==',
                    'value'    => 'menu_item',
                ],
            ],
        ],
        'show_in_graphql'     => 1,
        'graphql_field_name'  => 'menuItemFields',
        'graphql_types'       => [ 'FoodItem' ],
    ] );
}
add_action( 'acf/init', 'juiced_register_menu_item_acf_fields' );
